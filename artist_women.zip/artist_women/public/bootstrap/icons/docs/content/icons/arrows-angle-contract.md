---
title: Arrows angle contract
categories:
  - Arrows
tags:
  - arrow
  - resize
---
