---
title: Binoculars fill
categories:
  - Real world
tags:
  - distance
  - view
  - search
---
