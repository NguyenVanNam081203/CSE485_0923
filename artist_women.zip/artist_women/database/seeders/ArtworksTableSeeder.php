<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;
use App\Models\artworks;

class ArtworksTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        DB::table('artworks')->delete();
        $faker = Faker::create();
        for($i=0;$i<50;$i++){
            artworks::create([
                'artist_name' => $faker->name,
                'description' => $faker->paragraph(2,true),
                'art_type' => $faker->randomElement(['hoi hoa', 'am nhac', 'van hoc']),
                'media_link' => $faker->url(),
                'cover_image' => $faker->url(),
            ]);
        }
    }
}
