---
title: Calendar x
categories:
  - Date and time
tags:
  - date
  - time
  - month
  - remove
  - delete
---
