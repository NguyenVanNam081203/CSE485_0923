<?php

echo "Welcome to Laravel World";