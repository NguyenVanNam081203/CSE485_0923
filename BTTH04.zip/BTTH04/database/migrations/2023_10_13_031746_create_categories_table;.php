<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * 
     */
    public function up(): void
    {
        Schema::create('categories', function (Blueprint $table){
            $table->id(); // Tạo ra cột có id, tự động tăng, khóa chính
            $table->string("name");
            $table->string("description");
            $table->timestamps(); // Tạo ra 2 cột có tên là created_at và updated_at
            // Xóa cũng được, để mặc cũng được, giải thích sau
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
