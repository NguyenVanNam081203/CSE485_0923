<?php

echo "Welcome to Laravel World"; ?><?php /**PATH C:\xampp\htdocs\Laravel_project\BTTH04\resources\views/home.blade.php ENDPATH**/ ?>