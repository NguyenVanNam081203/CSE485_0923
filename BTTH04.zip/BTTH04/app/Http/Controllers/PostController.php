<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PostController extends Controller
{
    public function getAllPosts(){
        echo "All posts from here";
    }
}
