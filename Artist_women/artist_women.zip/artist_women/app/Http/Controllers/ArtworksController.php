<?php

namespace App\Http\Controllers;

use App\Models\artworks;
use Illuminate\Http\Request;


class ArtworksController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $artworks = artworks::paginate(5);
        return view('Artwork.home', compact('artworks'));
       
    }
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('Artwork.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $request->validate([
            'artist_name' => 'required',
            'description' => 'required',
            'art_type' => 'required',
            'media_link' => 'required',
            'cover_image' => 'required',
        ]);
    
        // Thêm bản ghi mới
        $artworks = artworks::create($request->all());
    
        // Lấy ID của bản ghi mới nhất trong trang index
        $latestId = artworks::latest()->first()->id;
    
        // Tạo flash message thông báo thành công
        session()->flash('success', 'Bản ghi ' . $artworks->id . ' đã được thêm thành công.');
    
        // Chuyển hướng đến trang 'artworks.index' với trang cuối cùng
        return redirect()->route('artworks.index', ['page' => artworks::paginate(5)->lastPage()]);
    }

    /**
     * Display the specified resource.
     */
    public function show(artworks $artworks)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(artworks $artwork)
    {
        //
        return view('Artwork.edit', compact('artwork'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, artworks $artwork)
    {
        //
        $request->validate([
            'artist_name' => 'required' ,
            'description'  => 'required',
            'art_type'=> 'required',
            ]);
        $artwork->update($request->all());
        // Tạo flash message thông báo thành công
        session()->flash('success', 'Bản ghi ' . $artwork->id . ' đã được sửa.');

        return redirect()->route('artworks.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(artworks $artwork)
    {
        $deletedId = $artwork->id; // Lấy ID của dữ liệu bị xóa
        $artwork->delete();
    
        // Tạo flash message với ID
        session()->flash('success', 'Mục có ID ' . $deletedId . ' đã được xóa thành công.');
    
        return redirect()->route('artworks.index');
    }
}