---
title: C circle
categories:
  - Shapes
tags:
  - copyright
---
